Since these examples are compiled with MinGW64 and EABI (binary calling convention) is different from the Microsoft one, the .lib and .dll in this folder were compiled with MinGW64 (the same that you find in release\Windows\Legacy|Win64).

If you want rebuild these examples using Visual Studio keep snap7.lib and snal7.dll from release\windows\win64

