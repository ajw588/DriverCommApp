Rich demos are written in Object pascal, so, to have more fun look at them.

There are no makefile/project, these files are good enough to be compiled with any Delphi/Freepascal release.

To run them you need the correct binary library (libsnap7.so or snap7.dll) either 32 or 64 bit.
Please copy them from release\<platform> folder to /usr/lib (unix) or win<platform> folder (windows).