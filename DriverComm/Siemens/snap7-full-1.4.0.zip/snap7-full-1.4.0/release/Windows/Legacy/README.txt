The libraries in these folders were built with MinGW32/64.
Use them only for Windows NT, Windows 2000, Windows 2003 Server.

They work also with Windows XP+ (Win7,Win8,Win2010) but there are some issues with the 64 bit dot net compilers.